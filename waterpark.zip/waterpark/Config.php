<?php $con = mysqli_connect("localhost","root","","waterpark");?>
