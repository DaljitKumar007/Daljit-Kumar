<?php include "Header.php" ?>
<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
            <div class="container text-center py-5" style="max-width: 900px;">
                <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Ticket Packages</h4>
                <ol class="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active text-primary">Ticket</li>
                </ol>    
            </div>
        </div>
        <!-- Header End -->

        <!-- Ticket Packages Start -->
        <div class="container-fluid py-5">
            <div class="container py-5">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 col-xl-4 wow fadeInUp" data-wow-delay="0.2s">
                        <div class="packages-item h-100">
                            <h4 class="text-primary">Ticket Packages</h4>
                            <h1 class="display-5 mb-4">Choose The Best Packages For Your Family</h1>
                            <p class="mb-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur adipisci facilis cupiditate recusandae aperiam temporibus corporis itaque quis facere, numquam, ad culpa deserunt sint dolorem autem obcaecati, ipsam mollitia hic.
                            </p>
                            <p><i class="fa fa-check text-primary me-2"></i>Best Waterpark in the world</p>
                            <p><i class="fa fa-check text-primary me-2"></i>Best Packages For Your Family</p>
                            <p><i class="fa fa-check text-primary me-2"></i>Enjoy Various Kinds of Water Park</p>
                            <p class="mb-5"><i class="fa fa-check text-primary me-2"></i>Win Up To 3 Free All Day Tickets</p>
                            
                        </div>
                    </div>
                   <?php
                   include "Config.php";
                   $query="SELECT * FROM `packages`";
                   $result=mysqli_query($con,$query);
                   while($row=mysqli_fetch_array($result)){ 
                   ?>
                    <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.4s" style="height:650px">
                        <div class="pricing-item bg-dark rounded text-center p-5 h-100">
                            <div class="pb-4 border-bottom">
                                <h2 class="mb-4 text-primary"><?php echo $row['package_name']; ?></h2>
                                <p class="mb-4"><?php echo $row['description'] ?></p>
                                <h2 class="mb-0 text-primary"><i class="bi bi-currency-rupee"></i><?php echo $row['price'] ?><span class="text-body fs-5 fw-normal">/<?php echo $row['peoples']; ?>Persons</span></h2>
                            </div>
                            <div class="py-4">
                                <p class="mb-4"><i class="fa fa-check text-primary me-2"></i><?php echo $row['feature1']; ?></p>
                                <p class="mb-4"><i class="fa fa-check text-primary me-2"></i><?php echo $row['feature2']; ?></p>
                                <p class="mb-4"><i class="fa fa-check text-primary me-2"></i><?php echo $row['feature3']; ?></p>
                                <p class="mb-4"><i class="fa fa-check text-primary me-2"></i><?php echo $row['feature4']; ?></p>
                                <p class="mb-4"><i class="fa fa-check text-primary me-2"></i><?php echo $row['feature5']; ?></p>
                            </div>
                            <a href="Booking_Form.php?id=<?php echo $row['id']; ?>" class="btn btn-light rounded-pill py-3 px-5"> Book Now</a>
                        </div>
                    </div>
                   <?php } ?>
                </div>
            </div>
        </div>
        <!-- Ticket Packages End -->
<?php include "Footer.php" ?>
