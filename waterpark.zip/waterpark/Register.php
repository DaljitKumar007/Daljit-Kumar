<?php include "Header.php" ?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Login 05</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="./Signup/css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section fw-bolder">USER REGISTER</h2>
				</div>
			</div>
			<?php
                    if (isset($_REQUEST['msg'])) {
                        echo '<div class="col-md-12 alert alert-info bg-info text-light mt-5 w-100">
                                ' . $_REQUEST['msg'] . '
                                <button type="button" class="close" onclick="this.parentElement.style.display=\'none\';">&times;</button>
                            </div>';
                    }
                    ?>

			<div class="row justify-content-center">
				<div class="col-md-7 col-lg-8">
					<div class="wrap">
						<div class="img" style="background-image: url(./Signup/images/bg-1.jpg);background-size:cover;height:300px"></div>
						<div class="login-wrap p-4 p-md-5">
			      	<div class="d-flex">
			      		<div class="w-100">
			      			<h3 class="mb-4">Register Here</h3>
			      		</div>
								<div class="w-100">
									<p class="social-media d-flex justify-content-end">
										<a href="#" class="social-icon d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a>
										<a href="#" class="social-icon d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a>
									</p>
								</div>
			      	</div>
						<form action="" class="signin-form" method="post">
			      		<div class="form-group mt-4">
			      			<input type="text" name="name" class="form-control" required>
			      			<label class="form-control-placeholder" for="username">Username</label>
			      		</div>
                          <div class="form-group mt-4">
			      			<input type="Email" name="email" class="form-control" required>
			      			<label class="form-control-placeholder" for="username">Email</label>
			      		</div>

		            <div class="form-group">
		              <input id="password-field" name="password" type="password" class="form-control" required>
		              <label class="form-control-placeholder" for="password">Password</label>
		              <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
		            </div>
                    <div class="form-group mt-4">
			      			<input type="text" name="contact" pattern="[0-9]{10}" class="form-control" required>
			      			<label class="form-control-placeholder" for="username">Contact</label>
			      		</div>
                          <div class="form-group mt-4">
			      			<textarea  class="form-control" name="address" required></textarea>
			      			<label class="form-control-placeholder" for="username">Address</label>
			      		</div>
		            <div class="form-group">
		            	<button type="submit" name="submit" class="form-control btn btn-primary rounded submit px-3">Register</button>
		            </div>
		           
		          </form>
		          <p class="text-center">Already Have an Account? <a data-toggle="tab" href="Login.php">Log In</a></p>
		        </div>
		      </div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>
<?php include "Footer.php" ?>
<?php
if(isset($_POST['submit'])){
    $name  = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $password  = $_REQUEST['password'];
    $contact = $_REQUEST['contact'];
    $address = $_REQUEST['address'];

    include "config.php";

    // Check if email already exists
    $checkQuery = "SELECT * FROM `users` WHERE `email`='$email'";
    $checkResult = mysqli_query($con, $checkQuery);

    if(mysqli_num_rows($checkResult) > 0) {
        // Email already exists
        echo "<script>window.location.assign('Register.php?msg=EMAIL ALREADY EXISTS!!')</script>";
    } else {
        // Proceed with registration
        $query = "INSERT INTO `users`(`name`,`email`,`password`,`contact`,`address`,`status`) VALUES ('$name','$email','$password','$contact','$address','Active')";
        $result = mysqli_query($con, $query);

        if($result > 0) {
            echo "<script>window.location.assign('Login.php?msg=CONGRATS REGISTRATION DONE')</script>";
        } else {
            echo "<script>window.location.assign('Register.php?msg=INVALID CREDENTIALS!!!!!!')</script>";
        }
    }
}
?>

