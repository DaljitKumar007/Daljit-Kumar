<?php include "AdminHeader.php" ?>
<!-- Content Start -->
<div class="content">
            <!-- Navbar Start -->
           <?php include "Navbar.php" ?>
            <!-- Navbar End -->
            <?php
                    if (isset($_REQUEST['msg'])) {
                        echo '<div class="alert alert-primary bg-primary text-light mt-5 w-100">
                                ' . $_REQUEST['msg'] . '
                                <button type="button" class="close" onclick="this.parentElement.style.display=\'none\';">&times;</button>
                            </div>';
                    }
                    ?>
            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                   
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Responsive Table</h6>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="bg-primary text-dark">
                                            <th scope="col">Sr No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Subject</th>
                                            <th scope="col">Message</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $s=1;
                                    include "../Config.php";
                                    $query = "SELECT * FROM `customer_queries`";
                                    $result = mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($result)){
                                    ?>
                                            <tr>
                                            <th scope="row"><?php echo $s; ?></th>
                                            <td><?php echo $row['name']; ?></td>
                                            <td><?php echo $row['email'];?></td>
                                            <td><?php echo $row['subject']; ?></td>
                                            <td><?php echo $row['message']; ?></td>
                                            
                                            <td>
                                            <a href="mailto:<?php echo $row['email']; ?>?subject=Re: <?php echo $row['subject']; ?>">
                                                <button class="btn btn-primary">Reply</button>
                                                 </a>
                                            </td>
                                           
                                        </tr>
                                      <?php $s++; } ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->


            <!-- Footer Start -->
           <?php include "AdminFooter.php" ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->