  <?php include "AdminHeader.php" ?>
  <!-- Content Start -->
  <div class="content">
            <!-- Navbar Start -->
           <?php include "Navbar.php" ?>
            <!-- Navbar End -->

            <?php
        include "../Config.php";
        $query = "select * from `packages`";
        $query1=  "select * from `users`";
        $query2=  "select * from `customer_queries`";
        $query3=  "select * from `bookings`";
        $result = mysqli_query($con, $query);
        $result1 = mysqli_query($con, $query1);
        $result2 = mysqli_query($con, $query2);
        $result3 = mysqli_query($con, $query3);
        $totalPackages = mysqli_num_rows($result); 
        $totalUsers = mysqli_num_rows($result1);
        $totalQueries = mysqli_num_rows($result2);
        $totalBookings = mysqli_num_rows($result3);

        ?>
            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-6">
                        <div class="bg-primary rounded d-flex align-items-center justify-content-between p-5" style="height:200px">
                            <i class="bi bi-people-fill fa-3x text-light" style="font-size:80px"></i>
                            <div class="ms-3">
                                <h3 class="mb-2 text-light" >Total Users</h3>
                                <h1 class="mb-0 text-light"><?php echo $totalUsers?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-6">
                        <div class="bg-primary rounded d-flex align-items-center justify-content-between p-5" style="height:200px">
                            <i class="bi bi-box2-heart-fill fa-3x text-light" style="font-size:80px"></i>
                            <div class="ms-3">
                                <h3 class="mb-2 text-light">Total Packages</h3>
                                <h1 class="mb-0 text-light"><?php echo $totalPackages ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-6">
                        <div class="bg-primary rounded d-flex align-items-center justify-content-between p-5" style="height:200px">
                        <i class="bi bi-bookmark-star-fill fa-3x text-light" style="font-size:80px"></i>
                            <div class="ms-3">
                                <h3 class="mb-2 text-light">Total Bookings</h3>
                                <h1 class="mb-0 text-light"><?php echo $totalBookings ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-6">
                        <div class="bg-primary rounded d-flex align-items-center justify-content-between p-5" style="height:200px">
                            <i class="bi bi-person-raised-hand fa-3x text-light" style="font-size:80px"></i>
                            <div class="ms-3">
                                <h3 class="mb-2 text-light">Total Queries</h3>
                                <h1 class="mb-0 text-light"><?php echo $totalQueries ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sale & Revenue End -->


           


            <?php include "AdminFooter.php" ?>
        </div>
        <!-- Content End -->