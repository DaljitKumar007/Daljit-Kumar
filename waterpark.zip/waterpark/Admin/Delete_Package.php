<?php 
	$id=$_REQUEST['id'];

	include "../Config.php";
	$query="delete from `packages` where id = '$id'";

	$result = mysqli_query($con,$query);

	if($result>0)
	{
	
		echo "<script>window.location.assign('Manage_Packages.php?msg=Package deleted successfully')</script>";
	}
	else{
		//echo mysqli_error($con);
		echo "<script>window.location.assign('Manage_Packages.php?msg=Try Again!!!!')</script>";
	}
?>