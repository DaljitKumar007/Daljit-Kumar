<?php 
// Check if booking_id is set in the request
if(isset($_REQUEST['booking_id'])){
    $id = $_REQUEST['booking_id'];
	echo $id;
    include "../Config.php";

   
    $query = "UPDATE `bookings` SET `booking_status` = 'Rejected' WHERE booking_id = '$id'";

 
    $result = mysqli_query($con, $query);

    
    if($result) {
       
       echo "<script>window.location.assign('RejectedBookings.php?msg=BOOKING REJECTED')</script>";
    } else {
        echo mysqli_error($con);
        
        echo "<script>window.location.assign('Manage_Bookings.php?msg=TRY AGAIN!!!!')</script>";
    }
} else {
    echo "Booking ID not provided.";
}
?>
