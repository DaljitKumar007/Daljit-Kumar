<?php include "AdminHeader.php" ?>
<!-- Content Start -->
<div class="content">
            <!-- Navbar Start -->
           <?php include "Navbar.php" ?>
            <!-- Navbar End -->
            <?php
                    if (isset($_REQUEST['msg'])) {
                        echo '<div class="alert alert-primary bg-primary text-light mt-5 w-100">
                                ' . $_REQUEST['msg'] . '
                                <button type="button" class="close" onclick="this.parentElement.style.display=\'none\';">&times;</button>
                            </div>';
                    }
                    ?>
            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                   
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h1 class="mb-4 text-center">Manage Bookings</h1>
                            <div class="table-responsive">
                            <?php 
                    include "../Config.php";
                    $query = "SELECT bookings.*, users.*, packages.*
                              FROM bookings
                              INNER JOIN users ON bookings.user_id = users.id
                              INNER JOIN packages ON bookings.package_id = packages.id
                              WHERE bookings.booking_status='Pending'";
                    $result = mysqli_query($con, $query);
                    
                    if (mysqli_num_rows($result) > 0) {
                    ?>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="bg-primary text-dark">
                                            <th scope="col">Sr No.</th>
                                            <th scope="col">Package Details</th>
                                            <th scope="col">User Details</th>
                                            <th scope="col">Booking Details</th>
                                            <th scope="col" colspan="2" class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>     
                    <?php 
                                $s = 1;
                                while($row = mysqli_fetch_array($result)) {
                                ?>
                                            <tr>
                                            <th scope="row"><?php echo $s; ?></th>
                                            <td>
                                                <li><span class="text-dark fw-bold">Name:</span><?php echo $row['package_name'] ?></li>
                                                <li><span class="text-dark fw-bold">Price:</span><i class="bi bi-currency-rupee"></i><?php echo $row['price'] ?></li>
                                                <li><span class="text-dark fw-bold">Persons:</span><?php echo $row['peoples'] ?></li>
                                                <li><span class="text-dark fw-bold">Features:</span></li>
                                                <ul type="circle">
                                                <li><?php echo $row['feature1'] ?></li>
                                                <li><?php echo $row['feature2'] ?></li>
                                                <li><?php echo $row['feature3'] ?></li>
                                                <li><?php echo $row['feature4'] ?></li>
                                                <li><?php echo $row['feature5'] ?></li>
                                                </ul>
                                                <li><span class="text-dark fw-bold">Description:</span><?php echo $row['description'] ?></li>
                                            </td>
                                            <td>
                                                <ul>
                                                <li><span class="text-dark fw-bold">Name:</span><?php echo $row['name'] ?></li>
                                                <li><span class="text-dark fw-bold">Email:</span><?php echo $row['email'] ?></li>
                                                <li><span class="text-dark fw-bold">Contact:</span><?php echo $row['contact'] ?></li>
                                                <li><span class="text-dark fw-bold">Address:</span><?php echo $row['address'] ?></li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul>
                                                <li><span class="text-dark fw-bold">Alternate Contact:</span><?php echo $row['alternate_contact'] ?></li>
                                                <li><span class="text-dark fw-bold">Date:</span><?php echo $row['date'] ?></li>
                                                </ul>
                                            </td>
                                            <td>
                                            <form action="Approving_Bookings.php" method="post">
							                <input type="hidden" name="booking_id" value="<?php echo $row['booking_id']; ?>">
							                <button type="submit" class="btn btn-success">Approve</button>
							                </form>
                                            </td>
                                            <td>
                                            <form action="Rejecting_Bookings.php" method="post">
                                            <input type="hidden" name="booking_id" value="<?php echo $row['booking_id']; ?>">
                                            <button type="submit" class="btn btn-danger">Reject</button>
                                            </form>
                                            </td>
                                        </tr>
                                      <?php $s++; }
                    } else {
                        echo '<p class="text-center text-dark">Currently there are no pending bookings!!</p>';
                    }
                    ?>
                                    </tbody>
                                </table>
                           
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->


            <!-- Footer Start -->
           <?php include "AdminFooter.php" ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->