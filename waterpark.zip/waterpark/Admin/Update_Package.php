<?php include "AdminHeader.php" ?>
 <!-- Content Start -->
 <div class="content">
            <!-- Navbar Start -->
            <?php include "Navbar.php"; ?>
            <!-- Navbar End -->

            <?php
                    if (isset($_REQUEST['msg'])) {
                        echo '<div class="alert alert-info bg-info text-light mt-5 w-100">
                                ' . $_REQUEST['msg'] . '
                                <button type="button" class="close" onclick="this.parentElement.style.display=\'none\';">&times;</button>
                            </div>';
                    }
                    $id=$_REQUEST['id'];
                  include "../Config.php";
                  $query1="select * from `packages` where id ='$id'";
                  $result1=mysqli_query($con,$query1);
                  $row=mysqli_fetch_array($result1);
                    ?>
            <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-8 offset-md-2">
                        <div class="bg-light rounded h-100 p-4">
                            <h1 class="mb-4 text-center">Add Packages</h1>
                            <form action="" method="post">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Package Name</label>
                                    <input type="text" name="package_name"
                                    value="<?php echo $row['package_name'] ?>"
                                    class="form-control" id="exampleInputEmail1"
                                        aria-describedby="emailHelp" required>
                                    
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Price</label>
                                    <input type="text" name="price" 
                                    value="<?php echo $row['price'] ?>"
                                    class="form-control" id="exampleInputPassword1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">No. Of Peoples</label>
                                    <input type="text" name="peoples"
                                    value="<?php echo $row['peoples'] ?>"
                                    class="form-control" id="exampleInputPassword1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Feature 1</label>
                                    <input type="text" name="feature1"
                                    value="<?php echo $row['feature1'] ?>"
                                    class="form-control" id="exampleInputPassword1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Feature 2</label>
                                    <input type="text" name="feature2"
                                    value="<?php echo $row['feature2'] ?>"
                                    class="form-control" id="exampleInputPassword1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Feature 3</label>
                                    <input type="text" name="feature3" 
                                    value="<?php echo $row['feature3'] ?>"
                                    class="form-control" id="exampleInputPassword1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Feature 4</label>
                                    <input type="text" name="feature4"
                                    value="<?php echo $row['feature4'] ?>"
                                    class="form-control" id="exampleInputPassword1">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Feature 5</label>
                                    <input type="text" name="feature5"
                                    value="<?php echo $row['feature5'] ?>"
                                    class="form-control" id="exampleInputPassword1">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Description</label>
                                    <textarea name="description"  class="form-control" required id="exampleInputPassword1"><?php echo $row['description']; ?></textarea>
                                </div>
                                
                                <button type="submit" name="submit" class="btn btn-primary w-50 py-3 px-5 offset-md-3">Save</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- Form End -->


            <?php include "AdminFooter.php" ?>
        </div>
        <!-- Content End -->
        <?php
    if(isset($_POST['submit'])){
    $id1=$_REQUEST['id'];
    $package_name = $_REQUEST['package_name'];
	$price=$_REQUEST['price'];
    $peoples=$_REQUEST['peoples'];
    $feature1=$_REQUEST['feature1'];
    $feature2=$_REQUEST['feature2'];
    $feature3=$_REQUEST['feature3'];
    $feature4=$_REQUEST['feature4'];
    $feature5=$_REQUEST['feature5'];
	$description=$_REQUEST['description'];
    
    include "../Config.php";
	
	
        $query = "update `packages` set `package_name`='$package_name',`price`='$price',`peoples`='$peoples',`feature1`='$feature1',`feature2`='$feature2',`feature3`='$feature3',`feature4`='$feature4',`feature5`='$feature5',`description`='$description'  where id='$id1'";     
		$result = mysqli_query($con, $query);
	
		if($result) {
			echo "<script>window.location.assign('Manage_Packages.php?msg=Data Updated successfully')</script>";
		} else {
			echo mysqli_error($con);
			echo "<script>window.location.assign('Update_Package.php?msg=TRY AGAIN!!')</script>";
		}
	
}
?>