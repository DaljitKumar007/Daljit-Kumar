<?php include "AdminHeader.php" ?>
<!-- Content Start -->
<div class="content">
            <!-- Navbar Start -->
           <?php include "Navbar.php" ?>
            <!-- Navbar End -->
            <?php
                    if (isset($_REQUEST['msg'])) {
                        echo '<div class="alert alert-primary bg-primary text-light mt-5 w-100">
                                ' . $_REQUEST['msg'] . '
                                <button type="button" class="close" onclick="this.parentElement.style.display=\'none\';">&times;</button>
                            </div>';
                    }
                    ?>
            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                   
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h1 class="mb-4 text-center">Manage Packages</h1>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="bg-primary text-dark">
                                            <th scope="col">Sr No.</th>
                                            <th scope="col">Package Name</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">No. of Peoples</th>
                                            <th scope="col">Feature 1</th>
                                            <th scope="col">Feature 2</th>
                                            <th scope="col">Feature 3</th>
                                            <th scope="col">Feature 4</th>
                                            <th scope="col">Feature 5</th>
                                            <th scope="col">Description</th>
                                            <th scope="col" colspan="2" class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $s=1;
                                    include "../Config.php";
                                    $query = "SELECT * FROM `packages`";
                                    $result = mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($result)){
                                    ?>
                                            <tr>
                                            <th scope="row"><?php echo $s; ?></th>
                                            <td><?php echo $row['package_name']; ?></td>
                                            <td class="d-flex"><i class="bi bi-currency-rupee"></i><?php echo $row['price'];?></td>
                                            <td><?php echo $row['peoples']; ?></td>
                                            <td><?php echo $row['feature1']; ?></td>
                                            <td><?php echo $row['feature2']; ?></td>
                                            <td><?php echo $row['feature3']; ?></td>
                                            <td><?php echo $row['feature4']; ?></td>
                                            <td><?php echo $row['feature5']; ?></td>
                                            <td><?php echo $row['description'] ?></td>
                                            <td>
                                                <a href="Update_Package.php?id=<?php echo $row['id'] ?>">
                                                <button class="btn btn-primary">Edit</button>
                                                 </a>
                                            </td>
                                            <td>
                                                <a href="Delete_Package.php?id=<?php echo $row['id']; ?>">
                                                <button class="btn btn-danger" >Delete</button>
                                    </a>
                                            </td>
                                        </tr>
                                      <?php $s++; } ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->


            <!-- Footer Start -->
           <?php include "AdminFooter.php" ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->