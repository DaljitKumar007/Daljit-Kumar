<?php include "Header.php" ?>
 <!-- Header Start -->
 <div class="container-fluid bg-breadcrumb">
            <div class="container text-center py-5" style="max-width: 900px;">
                <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">My Bookings</h4>
                <ol class="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Booking</a></li>
                    <li class="breadcrumb-item active text-primary">My Bookings</li>
                </ol>    
            </div>
        </div>
        <!-- Header End -->

        <div class="container-fluid about py-5">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-xl-12 wow fadeInUp" data-wow-delay="0.2s">
                        <h1 class="text-center text-primary mb-3">Booking Details</h1>
                    <div class="bg-primary rounded h-100 p-4">
                    <?php 
                    include "Config.php";
                    $query = "SELECT bookings.*, users.*, packages.*
                              FROM bookings
                              INNER JOIN users ON bookings.user_id = users.id
                              INNER JOIN packages ON bookings.package_id = packages.id
                              WHERE users.id = " . $_SESSION['id'] . ";";
                    $result = mysqli_query($con, $query);
                    
                    if (mysqli_num_rows($result) > 0) {
                    ?>
                        <table class="table table-dark table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Sr No.</th>
                                    <th scope="col">Package Details</th>
                                    <th scope="col">Alternate Contact</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Booking Status</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $s = 1;
                                while($row = mysqli_fetch_array($result)) {
                                ?>
                                    <tr>
                                        <th scope="row"><?php echo $s; ?></th>
                                        <td>
                                            <ul type="square">
                                            <li><span>Name:</span><?php echo $row['package_name'] ?></li>
                                            <li><span>Price:</span><i class="bi bi-currency-rupee"></i><?php echo $row['price'] ?></li>
                                            <li><span>Persons:</span><?php echo $row['peoples'] ?></li>
                                            <li><span>Features:</span>
                                        <ul type="disc">
                                            <li><?php echo $row['feature1'] ?></li>
                                            <li><?php echo $row['feature2'] ?></li>
                                            <li><?php echo $row['feature3'] ?></li>
                                            <li><?php echo $row['feature4'] ?></li>
                                            <li><?php echo $row['feature5'] ?></li>
                                        </ul>
                                        </li>
                                            <li><span>Description:</span><?php echo $row['description'] ?></li>
                                            </ul>
                                        </td>
                                        
                                        <td><?php echo $row['alternate_contact']; ?></td>
                                        <td><?php echo $row['date']; ?></td>
                                        <td><?php echo $row['booking_status']; ?></td>
                                       
                                    </tr>
                                    <?php 
                                    $s++;
                                } 
                                ?>
                            </tbody>
                        </table>
                    <?php 
                    } else {
                        echo '<p class="text-center text-light">Currently you dont have any bookings!!</p>';
                    }
                    ?>
                </div>
                    </div>
                  
                </div>
            </div>
        </div>
       

       
<?php include "Footer.php" ?>