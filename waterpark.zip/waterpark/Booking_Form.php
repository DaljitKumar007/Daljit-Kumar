<?php include "Header.php"; 
if (isset($_SESSION['email'])) {
?>
<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
            <div class="container text-center py-5" style="max-width: 900px;">
                <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Book Now</h4>
                <ol class="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Ticket Packages</a></li>
                    <li class="breadcrumb-item active text-primary">Booking</li>
                </ol>    
            </div>
        </div>
        <!-- Header End -->
<?php
$id = $_REQUEST['id'];
include "Config.php";
$query1 = "SELECT * FROM `packages` WHERE id='$id'";
$result1 = mysqli_query($con, $query1);
$row = mysqli_fetch_array($result1);

if (isset($_REQUEST['msg'])) {
   echo '<div class="col-6 offset-md-3 alert alert-secondary myalert text-light mt-5 ">
         ' . $_REQUEST['msg'] . '
         <button type="button" class="close offset-md-5" onclick="this.parentElement.style.display=\'none\';">&times;</button>
         </div>';
}
?>
<h2 class="text-dark text-uppercase mb-4 mt-3 text-center">book your ticket</h2>
<div class="col-xl-8 offset-md-2 fadeInRight animated mb-5" data-animation="fadeInRight" data-delay="1s" style="animation-delay: 1s;">
                                <div class="ticket-form p-5 bg-primary">
                                    
                                    <form action="" method="post">
                                        <div class="row g-4">
                                            <div class="col-12">
                                <input type="hidden" name="package_id" value="<?php echo $row['id']; ?>">
                                                <label>Package Name</label>
                                                <input type="text"  value="<?php echo $row['package_name']; ?>" class="form-control border-0 py-2" id="name" placeholder="Your Name" readonly>
                                            </div>
                                         
                                            <div class="col-12 col-xl-12">
                                                <label>Alternate Contact No.</label>
                                                <input type="phone" name="alternate_contact" pattern="[0-9]{10}" class="form-control border-0 py-2" id="phone" placeholder="Phone" required>
                                            </div>
                                           
                                            <div class="col-12">
                                            <label>Select Date</label>
                                            <input class="form-control border-0 py-2" name="date" type="date" required min="<?php echo date('Y-m-d'); ?>">
                                        </div>

                                            
                                            <div class="col-12">
                                                <button type="submit" name="submit" class="btn btn-dark w-100 py-3 px-5">Book Now</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
 <?php include "Footer.php"; ?>
 <?php 
if(isset($_POST['submit'])){

   $package_id = $_REQUEST['package_id'];
   $user_id = $_SESSION['id'];
   $alternate_contact = $_REQUEST['alternate_contact'];
   $date = $_REQUEST['date'];

   include "Config.php";

   if(!isset($_SESSION['email'])){
      echo "<script>window.location.assign('Login.php?msg=Please Login First!!!')</script>";
   } else {
      $query = "INSERT INTO `bookings`(`package_id`, `user_id`, `alternate_contact`, `date`, `booking_status`) VALUES ('$package_id','$user_id','$alternate_contact','$date','Pending')";
      $result = mysqli_query($con, $query);

      if($result > 0) {
         echo "<script>window.location.assign('MyBookings.php?msg=Booking successful')</script>";
      } else {
         echo mysqli_error($con);
         echo "<script>window.location.assign('Booking.php')</script>";
      }
   }
}
} else{
    echo "<script>window.location.assign('Login.php?msg=Please Login First!!!')</script>";

}
?>
